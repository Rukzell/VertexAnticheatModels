Not recommended for use on a public server. Use this for testing purposes.

Contact: rukzell(discord)